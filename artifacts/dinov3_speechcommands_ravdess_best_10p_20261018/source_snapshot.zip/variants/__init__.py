"""Optional experiment variants; the baseline entry points remain unchanged."""
